package com.my.ch.dto;

public class MemberDto {
	
	/**
	 user_id VARCHAR(50) PRIMARY KEY,
  	password VARCHAR(200),
  	name VARCHAR(50),
  	email VARCHAR(100) 
	 
	 */
	
	public String user_id;
	public String password;
	public String name;
	public String email;

}
